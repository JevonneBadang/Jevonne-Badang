#include "DHT.h"

// Define the pins connected to the components
#define DHTPIN 2     // Digital pin connected to the DHT22 data pin
#define LEDPIN 8     // Digital pin connected to the LED resistor

// Un-comment the sensor type you are using (DHT22 is active here)
#define DHTTYPE DHT22   // DHT 22  (AM2302), AM2321

// Initialize DHT sensor
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  // Start the serial communication
  Serial.begin(9600);
  Serial.println(F("DHT22 and LED Circuit Test"));

  // Set the LED pin as an output
  pinMode(LEDPIN, OUTPUT);

  // Initialize the DHT sensor
  dht.begin();
}

void loop() {
  // Wait a few seconds between measurements (DHT22 needs at least 2 seconds)
  delay(2000);

  // Reading temperature or humidity takes about 250 milliseconds!
  float humidity = dht.readHumidity();
  // Read temperature as Celsius (the default)
  float temperature = dht.readTemperature();

  // Check if any reads failed and exit early (to try again).
  if (isnan(humidity) || isnan(temperature)) {
    Serial.println(F("Failed to read from DHT sensor!"));
    return;
  }

  // Print the results to the Serial Monitor
  Serial.print(F("Humidity: "));
  Serial.print(humidity);
  Serial.print(F("%  |  Temperature: "));
  Serial.print(temperature);
  Serial.println(F("°C"));

  // --- LED Logic Control ---
  // Change '30.0' to whatever temperature threshold you want
  if (temperature > 30.0) {
    digitalWrite(LEDPIN, HIGH);  // Turn the LED ON
    Serial.println(F("-> Alert! Temperature is high. LED ON."));
  } else {
    digitalWrite(LEDPIN, LOW);   // Turn the LED OFF
    Serial.println(F("-> Temperature normal. LED OFF."));
  }
}
